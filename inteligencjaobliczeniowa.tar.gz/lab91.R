fct.act <- function(x) {
  1 / (1 + exp(-x))
}

forwardPass <- function(wiek,waga,wzrost){
  hidden1 <- fct.act((wiek*-0.46122+ waga*0.97314 + wzrost*-0.39203) + 0.80109)
  hidden2 <- fct.act((wiek*0.78548+ waga *2.10584 + wzrost*-0.57847) + 0.43529)
  output <- hidden1 * -0.81546 + hidden2 * 1.03775 + -0.2368
  return(output)
}

forwardPass(23,75,176)