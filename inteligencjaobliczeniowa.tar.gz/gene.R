library(GA) 

p <- c(100,300, 200, 40, 500, 70, 100,250,300,280,300)
w <- c(7, 7, 6, 2, 5, 6, 1,3,10,3,15) 
W <- 25 
n <- length(p) 

knapsack <- function(x) { 
  war <- sum(x * p)
  wag <- sum(x * w)
  if(wag > W){
    0
  }else{
    war
  }
}

gene <- ga(type="binary", 
          fitness=knapsack , 
          nBits=n, 
          maxiter=100,
          run=100,
          popSize=20,
          seed = 101
          )

iteration <- 1:100
max <- gene@summary[,1]
mean <- gene@summary[,2]




all <- c(mean,max)
up = max(all)
down = min(all)
plot(iteration, max,xaxt="n",ylim=c(down,up),
     type = "o", 
     col = "red", 
     lwd = 1,
     xlab = "Iteracje",
     ylab = "Max Fitness",
     main = "Zmiany w fitness",
     log = "x")  
axis(1, at=iteration, las=2)
lines(iteration, mean, col="yellow", type = "o",  lwd=1)

legend(x = 1985, y = 150, legend = c("max","srednia"), col = c("red","yellow"),lty=1,lwd=1)

