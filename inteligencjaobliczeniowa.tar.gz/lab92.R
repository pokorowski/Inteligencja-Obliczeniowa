library("neuralnet")

normalize <- function(x)
{
  return((x- min(x)) /(max(x)-min(x)))
}

iris <- read.csv("iris.csv")
iris$sepallength <- normalize(iris$sepallength) 
iris$sepalwidth<- normalize(iris$sepalwidth) 
iris$petallength <- normalize(iris$petallength) 
iris$petalwidth <- normalize(iris$petalwidth) 
 ind <- sample(2, nrow(iris), replace = TRUE, prob=c(0.7, 0.3))
trainset = iris[ind == 1,]
testset = iris[ind == 2,]
trainset$setosa = trainset$class== "Iris-setosa"
trainset$virginica = trainset$class== "Iris-virginica"
trainset$versicolor = trainset$class == "Iris-versicolor"

network = neuralnet(versicolor + virginica + setosa~ sepallength + sepalwidth + petallength + petalwidth, trainset, hidden=3)
Call: neuralnet(formula = versicolor + virginica + setosa ~ sepallength+ sepalwidth + petallength + petalwidth, data = trainset,hidden = 3)