#-----------------------------------------------------------------
#POSTAOWE OPERACJE
library(e1071)
library(party)
library(class)
library(ggplot2)
library(plyr)
library(dplyr)
library(randomForest)
library(MLmetrics)
library(dbscan)
library(arules)

#ustaw folder roboczy
setwd("E:/InteligencjaObliczeniowaProjekt")
#pobierz dane z pliku adult.csv.
adult <- read.csv(file="adult.csv", header=TRUE, sep=",",strip.white = T)
#-----------------------------------------------------------------
#Czyszczenie, preprocessing danych

#usun trzecia kolumne z bazy danych
adult<-adult[,-3]

#sprawdz ktore kolmny maja niokreslone wartosci

adult %>%
  summarise(
    workclass = sum(workclass == "?"),
    education = sum(education == "?"),
    marital.status = sum(marital.status == "?"),
    occupation = sum(occupation == "?"),
    relationship = sum(relationship == "?"),
    race = sum(race == "?"),
    sex = sum(sex == "?"),
    native.country = sum(native.country == "?")
  )

#zamien nieokreslone wartosci na Other/unknown
levels(adult$workclass)[1] <- 'Other/Unknown'
levels(adult$occupation)[1] <- 'Other/Unknown'
levels(adult$native.country)[1] <- 'Other/Unknown'

adult %>%
  summarise(
    workclass = sum(workclass == "?"),
    occupation = sum(occupation == "?"),
    native.country = sum(native.country == "?")
  )

#polacz grupy w Government
adult$workclass <- gsub('^Federal-gov', 'Government', adult$workclass)
adult$workclass <- gsub('^Local-gov', 'Government', adult$workclass)
adult$workclass <- gsub('^State-gov', 'Government', adult$workclass) 

# polacz grupy w  Sele-Employed job
adult$workclass <- gsub('^Self-emp-inc', 'Self-Employed', adult$workclass)
adult$workclass <- gsub('^Self-emp-not-inc', 'Self-Employed', adult$workclass)

# polacz grupy w  Other/Unknown
adult$workclass <- gsub('^Never-worked', 'Other/Unknown', adult$workclass)
adult$workclass <- gsub('^Without-pay', 'Other/Unknown', adult$workclass)


adult$marital.status <- gsub('Married-AF-spouse', 'Married', adult$marital.status)
adult$marital.status <- gsub('Married-civ-spouse', 'Married', adult$marital.status)
adult$marital.status <- gsub('Married-spouse-absent', 'Married', adult$marital.status)
adult$marital.status <- gsub('Never-married', 'Single', adult$marital.status)

#pzamien nazwy grup
adult$income <- gsub('^<=50K', 'low', adult$income)
adult$income <- gsub('^>50K', 'high', adult$income)


#zapisz zmienione kolumny jako factor
adult$workclass <- as.factor(adult$workclass)
adult$occupation <- as.factor(adult$occupation)
adult$native.country <- as.factor(adult$native.country)
adult$income <- as.factor(adult$income)
adult$sex<- as.factor(adult$sex)
adult$marital.status <- as.factor(adult$marital.status)
-----------------------------------------------------------------------------------------------------------------------
#Zaleznosci roznych kolumn z kolumna income

#policz ile jest osob z malymi i duzymi zarobkami
incomeFreq <- adult %>% count(income)
lowIncFreq <-as.numeric(incomeFreq[2,2])
highIncFreq <-as.numeric(incomeFreq[1,2])

#funkcja generujaca procentowy wykres kolowy
generatePieChart <-function(freq,pieLabels,title) { 
  lbls <- pieLabels
  pct <- round(freq/sum(freq)*100)
  lbls <- paste(lbls, pct) 
  lbls <- paste(lbls,"%",sep="") 
  pie(freq,labels = lbls, col=rainbow(length(lbls)),
      main=title)
}

#wygeneruj wykres kolowy pokazujacy stosnek liczby zarobkow dla populacji
generatePieChart(c(lowIncFreq,highIncFreq),c("low","high"),"Representing people by income")
  
#wygeneruj wykres zaleznosc miedzy wiekiem a zarobkami
ggplot(adult) + aes(x=as.numeric(age), group=income, fill=income) + 
geom_histogram(binwidth=1, color='black') +
xlab("age") + ylab("number of people") 

#tabela z populacja dla kazdego typu pracy dla kazdej wysokosci zarobkow
count <- table(adult[adult$workclass == 'Government',]$income)["low"]
count <- c(count, table(adult[adult$workclass == 'Government',]$income)["high"])
count <- c(count, table(adult[adult$workclass == 'Other/Unknown',]$income)["low"])
count <- c(count, table(adult[adult$workclass == 'Other/Unknown',]$income)["high"])
count <- c(count, table(adult[adult$workclass == 'Private',]$income)["low"])
count <- c(count, table(adult[adult$workclass == 'Private',]$income)["high"])
count <- c(count, table(adult[adult$workclass == 'Self-Employed',]$income)["low"])
count <- c(count, table(adult[adult$workclass == 'Self-Employed',]$income)["high"])
count <- as.numeric(count)

#stworz i odpowiednio przeksztalcdataframe z danymi z powyzszej tabeli
industry <- rep(levels(adult$workclass), each = 2)
income <- rep(c('low', 'high'), 4)
df <- data.frame(industry, income, count)
df <- ddply(df, .(industry), transform, percent = count/sum(count) * 100)
df <- ddply(df, .(industry), transform, pos = (cumsum(count) - 0.5 * count))
df$label <- paste0(sprintf("%.0f", df$percent), "%")

#wygeneruj tabele przedstawiajaca stosuk zarobkow do typu pracy
ggplot(df, aes(x = industry, y = count, fill = income)) +
  geom_bar(stat = "identity") +
  geom_text(aes(y = pos, label = label), size = 2) + 
  ggtitle('Income by Industry')


-----------------------------------------------------------------------------------------------------  
#Proste dane statystyczne np. srednia, odchylenie, min, max dla kazdej z kolumn



#wektor zawierajacy indeksy kolumn zawierajacych dane liczbowe
numColumnsIndices <- c(1,4,10,11,12)

#nazwy kolumn zawierajacych dane liczbowe
nunColumnsHeaders <- colnames(adult)[numColumnsIndices]
#dlugosc wektora numColumnsIndices
nCIL <- length(numColumnsIndices)
#wektor nazw badanych danych
basicDataFunctionsNames <- c("mean","min","max","standard.deviation")

#funkcja wyliczajaca srednia dla wszystkich kolumn
meanAll<-function(csvData){
  means <- c(1:nCIL)*0
  for (i in 1:nCIL) {
    means[i] <- mean(csvData[,numColumnsIndices[i]])
  }
  return(means)
}
#funkcja wyliczajaca minimum dla wszystkich kolumn
minAll<-function(csvData){
  mins <- c(1:nCIL)*0
  for (i in 1:nCIL) {
    mins[i] <- min(csvData[,numColumnsIndices[i]])
  }
  return(mins)
}
#funkcja wyliczajaca maksimum dla wszystkich kolumn
maxAll<-function(csvData){
  maxs <- c(1:nCIL)*0
  for (i in 1:nCIL) {
    maxs[i] <- max(csvData[,numColumnsIndices[i]])
  }
  return(maxs)
}
#funkcja wyliczajaca odczylenie standardowe dla wszystkich kolumn
standardDevationAll<-function(csvData){
  sds <- c(1:nCIL)*0
  for (i in 1:nCIL) {
    sds[i] <- sd(csvData[,numColumnsIndices[i]])
  }
  return(sds)
}

#macierz zawierajaca informacje o wynikach funkcji
functionsComparisonMatrix <- rbind(
  meanAll(adult),
  minAll(adult),
  maxAll(adult),
  standardDevationAll(adult)
)

#dodaj nazwy badanych kolmn do macierzy
colnames(functionsComparisonMatrix) <- nunColumnsHeaders
#dodaj nazwy badanych danych do macierzy
rownames(functionsComparisonMatrix) <- basicDataFunctionsNames 


#zapisz macierz do pliku csv
write.csv(functionsComparisonMatrix,"ProbMatrix.csv")
#---------------------------------------------------------------------------------------------------------------
#Klasyfikacja

adultNum <- adult
#indeksy kolumn nienumerycznych
stringColumnsIndices <- c(2,3,5,6,7,8,9,13)

#funkcja zamieniaja dane nienumeryczne na numeryczne
stringDataToNumeric<-function(csvData){
 
  for (i in stringColumnsIndices) {
    csvData[,i] <- as.numeric(csvData[,i])
  }
  return(csvData)
}

#bazadana baza z sammi kolumnami numerycznymi
adultNum <- stringDataToNumeric(adultNum)

#wyznacz podzial dla zbioru treninowego i testowego
ran <- sample(1:nrow(adult), 0.7 * nrow(adult)) 

##funkcja normalizacyjna
nor <-function(x) { (x -min(x))/(max(x)-min(x))   }

##przeprowadz normalizacje dla kolumn numerycznych
adult_norm <- as.data.frame(lapply(adultNum[,1:13], nor))
#Ekstracja zbioru treningowego
adult_train <- adult_norm[ran,] 
#Ekstracja zbioru testowego
adult_test <- adult_norm[-ran,] 
#Ekstracja ostatniej kolumny zbioru treningowego
adult_train_category <- adultNum[ran,14]
#Ekstracja ostatniej kolumny zbioru treningowego
adult_test_category <- adultNum[-ran,14]


#funkcja obliczaj�ca dokladnosc na podstawie macierzy bledow
accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}
#wektory zer do przechowywania dokladnosci badanych algorytmow dla kazdej z iteracji
acrf <- c(1:10)*0
ac3 <- c(1:10)*0
ac5 <- c(1:10)*0
ac11 <- c(1:10)*0
acb <- c(1:10)*0
act <- c(1:10)*0


for (i in 1:3) {
#formula uzywana w niektorych klasyfikacjach
myFormula <- income ~ .
#trenuj random forest
rf3 <- randomForest(myFormula, data=adultNum[ran,], ntree = 1000)
#klasyfikacja random forest
rf3.pred.prob <- predict(rf3, newdata = adultNum[-ran,], type = 'prob')
rf3.pred <- predict(rf3, newdata = adultNum[-ran,], type = 'class')

#trnuj i klasyfikuj knn
pr3 <- knn(adult_train,adult_test,cl=adult_train_category,k=3)
pr5 <- knn(adult_train,adult_test,cl=adult_train_category,k=5)
pr11 <- knn(adult_train,adult_test,cl=adult_train_category,k=11)

#trenuj bayes
bayes <- naiveBayes(adult_train,adult_train_category)
#trenuj drzewo
adult_ctree <- ctree(myFormula, data=adultNum[ran,])
#klasyfikuj dzrzewo
test_predict <- predict(adult_ctree,adultNum[-ran,],type="response")

#macierz bledow dla kazdego z algorytmow
tab_rf <- table(rf3.pred,adult_test_category)
tab3 <- table(pr3,adult_test_category)
tab5 <- table(pr5,adult_test_category)
tab11 <- table(pr11,adult_test_category)
tab_bayes <- table(predict(bayes, adult_test), adult_test_category)
tab_tree <- table(test_predict,adultNum[-ran,]$income)

#zapisywanie dokladnosci algorytmow dla danej iteracji
acrf[i] = accuracy(tab_rf)
ac3[i] = accuracy(tab3)
ac5[i] = accuracy(tab5)
ac11[i] = accuracy(tab11)
acb[i] = accuracy(tab_bayes)
act[i] = accuracy(tab_tree)
}


#zapisz usrednione dokladnosci alogrytmow do wektoru
Accuracy <- round(c(sum(ac3)/3,sum(ac5)/3,sum(ac11)/3,sum(acb)/3,sum(act)/3,sum(acrf)/3),4)

#zapisz nazwy badanych metod klafikacyjnych do wektoru
Clasificator <- c("knn3","knn5","knn11","naive_bayes","decision_tree","random_forest")
df <- data.frame(Clasificator,Accuracy)
#stworz i wyswietl wykres porownujacy dokladnosci dla kazdego z algorytmow
ggplot(data=df, aes(x=Clasificator, y=Accuracy, fill=Clasificator )) +
  geom_bar(stat="identity")+
  geom_text(aes(label=Accuracy), vjust=1.6, color="white", size=3.5)+
  theme_minimal()
#-------------------------------------------------------------------------------------------------
#Grupowanie

adultGroup <- adult
adultGroup<- stringDataToNumeric(adultGroup)


##przeprowadz normalizacje dla kolumn numerycznych
adultGroup_norm <- as.data.frame(lapply(adultGroup[,1:13], nor))
##przypisz zmiennej wartosci kolumny income
adultGroup_head <- adultGroup[,"income"]
adultGroupNum_head <- as.numeric(adultGroup_head)
#wylicz kmeans
groupResult<- kmeans(adultGroup_norm ,2)
#pokaz dystrybucje grup dla k means
table(groupResult$cluster,adultGroup_head)

#przedstaw rozmieszczenie koumn w klastrach
plot(adultGroup_norm[c(1,4)], col=groupResult$cluster)
plot(adultGroup_norm[c(4,12)], col=groupResult$cluster)
plot(adultGroup_norm[c(1,12)], col=groupResult$cluster)

#sprawd czystosc klastra
MLmetrics::Accuracy(groupResult$cluster,adultGroupNum_head)

#grupowanie DBSCAN epsilon=0.99 min liczba grup 2
groupResultDbs <- dbscan::dbscan(adultGroup_norm, 0.99, 2)
table(groupResultDbs$cluster,adultGroup_head)
plot(adultGroup_norm[c(1,4)], col=groupResultDbs$cluster)
plot(adultGroup_norm[c(4,12)], col=groupResultDbs$cluster)
plot(adultGroup_norm[c(1,12)], col=groupResult$cluster)
MLmetrics::Accuracy(groupResultDbs$cluster,adultGroupNum_head)
#-------------------------------------------------------------------------------------------------
#Reguly asocjacyjne

rulesAdult <- adult

#pogrupuj dane liczbowe dla kolumn age
rulesAdult <- rulesAdult %>% mutate(age = case_when(age >= 16  & age <= 24 ~ "adolescent",
                                             age > 24  & age <= 64 ~  "adult",
                                             age >64 ~ "senior"))
rulesAdult$age <- as.factor(rulesAdult$age)


rulesAdult <- rulesAdult %>% mutate(hours.per.week = case_when( hours.per.week <= 20 ~ "0-20",
                                                    hours.per.week > 20  & hours.per.week <= 40 ~  "21-40",
                                                    hours.per.week > 40 ~ "40<"))
rulesAdult$hours.per.week<- as.factor(rulesAdult$hours.per.week)

#indeksy badanych regu�
stringColumnsRuleIndices1 <- c(1,2,3,5,6,7,8,9,12,13,14)
 
#wyznacz reguly 
rules <- apriori(rulesAdult[,stringColumnsRuleIndices1],
                 parameter = list(minlen=2, supp=0.03, conf=0.70),
                 appearance = list(rhs=c("income=low", "income=high"),
                                   default="lhs"),
                 control = list(verbose=F))

#posortuj reguly dla lift
rules.sorted <- sort(rules, by="lift")

#pozbadz sie powtarzajacych regul
subset.matrix <- is.subset(rules.sorted, rules.sorted)
subset.matrix[lower.tri(subset.matrix, diag=T)] <- FALSE
redundant <- colSums(subset.matrix, na.rm=T) >= 1
which(redundant)
rules.pruned <- rules.sorted[!redundant]
#pokaz skrocone liste regul
inspect(rules.pruned)

inspect(subset(rules.pruned, subset = rhs %in% "income=high"))
inspect(sort(rules.pruned, by="support"))